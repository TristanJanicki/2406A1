{
	name: "Tristan Janicki",
	sid: "101080372",
	email: "tristanjanicki@cmail.carleton.ca",
	nodeV: "v10.15.0",
	npmV: "6.4.1",
	computerVersion: "Windows 10.0.17134 Build 17134",
	installInstructions: "Have node package manager installed. Have nodejs installed.",
	launchInstructions: "If you're reading this you've most likely unzipped the files in 2406A1.zip. If not do so. Once you have the extracted files then change your working directory to _RootDirectoryOfUnzippedFiles/2406A1/code and then execute the command node server.js. After this is executed you should see an indication that the server has started running and it will print out the url that you should visit to test the app. Input that url into your browser of choice (preferably chrome as thats what I have been testing on) and input the name of one of the predetermined songs. The rest of the testing instructions are probably in your rubric.",
	testURL: "http://localhost:3000/assignment1.html",
	problems: "Problems included transpose up for complex and sharp chords not being done at time of submission. I didn't budget enough time for solving this and currently am 5minutes past the midnight deadline so I'll submit what I have (which is everything working for the transpose down behaviours) and then fix transposeUp so it too handles complex and sharp chords and resubmit (this is just a matter of inverting a couple of behaviours)."
	
	

}