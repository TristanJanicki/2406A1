let words = []
let wordBeingMoved
let canvas
let context
let deltaX, deltaY
let l1 = "[A] [A#] [B] [C] [C#] [D] [D#] [E] [F] [F#] [G] [G#]".split(" ") // first list of chords
let l2 = "[A] [Bb] [B] [C] [Db] [D] [Eb] [E] [F] [Gb] [G] [Ab]".split(" ") // second list of chords
let originalChord = ""
let chordColor = "green"

function indexOf(key, l) {
    for (var i = 0; i < l.length; i++) {
        if(l[i].letter !== undefined){
            if(l[i].letter === key){ // modified this so that it works both when passing in the list of chords and the list of words
                return i
            }
        }else{
            if (l[i] === key) {
                return i
            }
        }
    }
    return -1
}

function transposeUp() {

    for (var i = 0; i < words.length; i++) {
        if (words[i].isChord) {

            if (words[i].letter.indexOf("/") !== -1) {

            }
            
            let i1 = indexOf(words[i].letter.replace(" ", ""), l1)
            let i2 = indexOf(words[i].letter.replace(" ", ""), l2)

            if (i1 !== -1) {
                words[i].letter = l1[((i1 + 1) % l1.length)]
            } else {
                words[i].letter = l2[((i2 + 1) % l2.length)]
            }
            
        }
    }
    drawCanvas()
}

function isComplexChord(chord){
    return (chord.indexOf("/") !== -1)
}

function isSharpChord(chord){
    return (chord.indexOf("#") !== -1)
}

function getNewChord(chord, dir){
    let i1 = indexOf(chord, l1)
    let i2 = indexOf(chord, l2)

    if(i1 !== -1){
        if(dir === "up"){
            return l1[((i1 + 1) % l1.length)]
        }else{ // dir === down
            if((i1 - 1) < 0){
                return l1[l1.length - 1]
            }else{
                return l1[i1 - 1]
            }
        }
    }else{
        if(dir === "up"){
            return l2[((i2 + 1) % l2.length)]
        }else{
            if((i2 - 1) < 0){
                return l2[l2.length - 1]
            }else{
                return l2[i2 - 1]
            }
        }
    }
}

function transposeDown() {
    for (var i = 0; i < words.length; i++) {
        if (words[i].isChord) {

            if(isComplexChord(words[i].letter)){
                let splits = words[i].letter.split("/")
                
                splits[0] += "]"
                splits[1] = "[" + splits[1]

                console.log(splits)

                let part1 = getNewChord(splits[0])
                let part2 = getNewChord(splits[1])

                part1 = part1.replace("[", "")
                part1 = part1.replace("]", "")

                part2 = part2.replace("[", "")
                part2 = part2.replace("]", "")

                console.log("part 1 = " + part1)
                console.log("part 2 = " + part2)
                

                words[i].letter = "[" + part1 + "/" + part2 + "]"
            }else if (isSharpChord(words[i].letter)){
                console.log("isSharpChord")
                let chord = words[i].letter.substring(0, words[i].letter.indexOf("#") + 1) + "]"

                let i1 = indexOf(chord, l1)
                let i2 = indexOf(chord, l2)

                if(i1 !== -1){
                    if((i1 - 1) < 0){
                        console.log("chord is " + words[i].letter)
                        console.log("turing chord into " + l1[l1.length - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                        words[i].letter = l1[l1.length - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#") + 1)
                        //console.log("XXX 1 " + l1[l1.length - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                    }else{
                        console.log("chord is " + words[i].letter)
                        console.log("turing chord into " + l1[i1 - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                        words[i].letter = l1[i1 - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#") + 1)
                        //console.log("XXX 2" + l1[i1 - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                    }
                }else{

                    if((i2 - 1) < 0){
                        words[i].letter = l2[l2.length - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#") + 1)
                    }else{
                        words[i].letter = l2[i2 - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#") + 1)
                    }

                }

                //console.log(chord)

            }else{

                let i1 = indexOf(words[i].letter.replace(" ", ""), l1)
                let i2 = indexOf(words[i].letter.replace(" ", ""), l2)
                
                //console.log("1words[i] = " + words[i].letter)
                if (i1 !== -1) {
    
                    if ((i1 - 1) < 0) {
                        words[i].letter = l1[l1.length - 1]
                    } else {
                        words[i].letter = l1[i1 - 1]
                    }
    
                } else {
                    if ((i2 - 1) < 0) {
                        words[i].letter = l2[l2.length - 1]
                    } else {
                        words[i].letter = l2[i2 - 1]
                    }
                }

            }   
            //console.log("2words[i] = " + words[i].letter)
        }
    }

    let firstChord = getFirstChord()
    console.log("first chord = " + firstChord)
    console.log("original chord = " + originalChord)
    if(firstChord != originalChord){
        chordColor = "yellow"
    }else{
        chordColor = "green"
    }

    drawCanvas()
}

function getFirstChord(){
    for(let word of words){
        if(word.isChord){
            return word.letter
        }
    }
}

function requestSong() {

    let request = {
        type: "song",
        title: $("#requestField").val()
    }

    let reqStr = JSON.stringify(request)

    //console.log(reqStr)
    $.post("requestSong", reqStr, function (data, status) {

        console.log("Server Response: " + data)
        let parsed = JSON.parse(data)
        if (parsed.status === "success") {
            constructWords(parsed)
            constructPara(parsed.song.data)
        } else {
            alert("Could not find " + $("#requestField").val())
        }
    })
}


function isChord(word) {
    return (word.indexOf("[") !== -1)
}

function constructPara(data) {
    let htmlString = ""

    for (let i in data) {
        let cc = String.fromCharCode(data[i])
        if (cc === "\n" || cc === "↵") {
            htmlString += "<br>"
        } else {
            htmlString += cc
        }
    }

    let para = document.createElement("p")
    para.innerHTML = htmlString
    document.getElementById("lyricArea").appendChild(para)
}

function constructWords(data) {
    let tData = data.song.data // short hand for textData

    if (data.hasOwnProperty("song")) {
        //console.log(typeof data)

        words = []
        let masterString = ""

        for (var i = 0; i < tData.length; i++) {

            let cc = String.fromCharCode(tData[i])
            masterString += cc


        }
        
        masterString = masterString.replace(/\[/g, " [")
        masterString = masterString.replace(/\]/g, "] ")

        let lines = masterString.split("\n")
        
        let yPos = 30
        for(let line of lines){
            let xPos = 20
            let splits = line.split(" ")
            //console.log(words)
            for(let word of splits){
                //console.log(word)
                let ic = isChord(word)
                words.push({letter: word, x: xPos, y: yPos, isChord: ic})
                xPos += (word.length * 17)//(context.measureText(word).width + 55)
            }
            yPos += 40
        }
        //console.log(words)
        originalChord = getFirstChord();
        drawCanvas()
    }
}

/**
 * This is modified code from tutorial 2.
 * @param {the x position of the mouse when clicked, relative to the top left corner of the canvas} aCanvasX 
 * @param {the y position of the mouse when clicked, relative to the top left corner of the canvas} aCanvasY 
 */
function getWordAtLocation(aCanvasX, aCanvasY) {

    let context = canvas.getContext("2d")

    

    for (let i = 0; i < words.length; i++) {
        let width = words[i].x + (context.measureText(words[i].word).width * 0.6) // yeah I agree that this is stupid
        // but for some reason when I ported this function from the tutorial 2 code it created a HUGE hit box for any given word
        // which in turn made you able to move a word even if you clicked on an area way to the right of its last character.
        if (aCanvasX >= words[i].x && aCanvasX <= width && Math.abs(words[i].y - aCanvasY) < 15) {
            return words[i]
        }
    }
    return null
}

function handleMouseUp(e) {

    e.stopPropagation()

    //$("#canvas1").off(); //remove all event handlers from canvas
    //$("#canvas1").mousedown(handleMouseDown); //add mouse down handler

    //remove mouse move and mouse up handlers but leave mouse down handler
    $("#canvas1").off("mousemove", handleMouseMove) //remove mouse move handler
    $("#canvas1").off("mouseup", handleMouseUp) //remove mouse up handler

    drawCanvas() //redraw the canvas
}

function handleMouseDown(e) {

    //get mouse location relative to canvas top left
    let rect = canvas.getBoundingClientRect()
    //var canvasX = e.clientX - rect.left
    //var canvasY = e.clientY - rect.top
    let canvasX = e.pageX - rect.left //use jQuery event object pageX and pageY
    let canvasY = e.pageY - rect.top
    //console.log("mouse down:" + canvasX + ", " + canvasY)

    wordBeingMoved = getWordAtLocation(canvasX, canvasY)
    //console.log(wordBeingMoved.word)
    if (wordBeingMoved != null) {
        deltaX = wordBeingMoved.x - canvasX
        deltaY = wordBeingMoved.y - canvasY
        //document.addEventListener("mousemove", handleMouseMove, true)
        //document.addEventListener("mouseup", handleMouseUp, true)
        $("#canvas1").mousemove(handleMouseMove)
        $("#canvas1").mouseup(handleMouseUp)

    }

    // Stop propagation of the event // TODO:  stop any default
    // browser behaviour

    e.stopPropagation()
    e.preventDefault()

    drawCanvas()
}

function handleMouseMove(e) {

    //get mouse location relative to canvas top left
    if (wordBeingMoved != null) {

        let rect = canvas.getBoundingClientRect()
        let canvasX = e.pageX - rect.left
        let canvasY = e.pageY - rect.top

        wordBeingMoved.x = canvasX + deltaX
        wordBeingMoved.y = canvasY + deltaY

    }


    e.stopPropagation()

    drawCanvas()
}

function handleKeyDown(e) {
    // KEY_CODE.ENTER = 13
    if (e.which === 13) {
        requestSong()
    }
}

function drawCanvas() {

    context.font = '16pt Arial'
    context.fillStyle = 'white'
    context.fillRect(0, 0, canvas.width, canvas.height) //erase canvas
    context.fillStyle = 'cornflowerblue'

    for (let i = 0; i < words.length; i++) {

        //console.log(words[i])
        let data = words[i]

        if (data.isChord) {
            context.strokeStyle = chordColor
        } else {
            context.strokeStyle = "blue"
        }

        context.fillText(data.letter, data.x, data.y)
        context.strokeText(data.letter, data.x, data.y)

    }


}

$(document).ready(function () {

    canvas = document.getElementById("canvas1")
    context = canvas.getContext("2d")

    $("#canvas1").mousedown(handleMouseDown)
    $("#canvas1").mousemove(handleMouseMove)
    $("#tDown").click(transposeDown)
    $("#tUp").click(transposeUp)
    $("#submitB").click(requestSong)
    $(document).keydown(handleKeyDown)

    //$(document).keyup(handleKeyUp)

    $("#requestField").val('Peaceful Easy Feeling')
    $("#submitB").click()


})

