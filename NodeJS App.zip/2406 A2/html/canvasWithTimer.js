/*
Client-side javascript for 2406 assignment 1
COMP 2406 (c) Louis D. Nel 2018

*/
let words = [] //array of drag-able lyrics or chord words
let wordMatrix = [] // 2D array of y coordinate, constituent words that make up that line of text
let drawingArray = [] // an array of words that will only be used in the drawing process
let l1 = "[A] [A#] [B] [C] [C#] [D] [D#] [E] [F] [F#] [G] [G#]".split(" ") // first list of chords
let l2 = "[A] [Bb] [B] [C] [Db] [D] [Eb] [E] [F] [Gb] [G] [Ab]".split(" ") // second list of chords
let originalChord = ""
let chordColor = "green"
//leave this moving word for fun and for using it to
//provide status info to client.
//NOT part of assignment requirements
let movingString = {
  word: "Moving",
  x: 100,
  y: 100,
  xDirection: 1, //+1 for rightwards, -1 for leftwards
  yDirection: 1, //+1 for downwards, -1 for upwards
  stringWidth: 50, //will be updated when drawn
  stringHeight: 24
} //assumed height based on drawing point size


let timer //timer for animation of moving string etc.
let wordBeingMoved //word being dragged by the mouse
let deltaX, deltaY //location where mouse is pressed relative to word origin
let canvas = document.getElementById('canvas1') //our drawing canvas
let fontPointSize = 18 //point size for chord and lyric text
let wordHeight = 20 //estimated height of a string in the editor
let editorFont = 'Courier New' //font for your editor -must be monospace font
let lineHeight = 40 //nominal height of text line
let lyricLineOffset = lineHeight * 5 / 8 //nominal offset for lyric line below chords
let topMargin = 40 //hard coded top margin white space of page
let leftMargin = 40 //hard code left margin white space of page

let transposedByNSemitones = 0 //transposition in semitones

let wordTargetRect = {
  x: 0,
  y: 0,
  width: 0,
  height: 0
} //used for debugging
//rectangle around word boundary

/** transposition code from A1 */
function indexOf(key, l) {
    for (var i = 0; i < l.length; i++) {
        if(l[i].word !== undefined){
            if(l[i].word === key){ // modified this so that it works both when passing in the list of chords and the list of words
                return i
            }
        }else{ // probably undeeded as i ended up keeping them in the same array
            if (l[i] === key) {
                return i
            }
        }
    }
    return -1
}

function isChord(str){
  return str.indexOf("[") !== -1
}

function transposeUp() {

    for (var i = 0; i < words.length; i++) {
        if (words[i].chord) {

            if(isComplexChord(words[i].word)){

                let splits = words[i].word.split("/")
                
                splits[0] += "]"
                splits[1] = "[" + splits[1]

                //console.log(splits)

                let part1 = getNewChord(splits[0], "up")
                let part2 = getNewChord(splits[1], "up")

                part1 = part1.replace("[", "")
                part1 = part1.replace("]", "")

                part2 = part2.replace("[", "")
                part2 = part2.replace("]", "")

                //console.log("part 1 = " + part1)
                //console.log("part 2 = " + part2)
                

                words[i].word = "[" + part1 + "/" + part2 + "]"

            }
            else if(isSharpChord(words[i].word)){

                let chord = words[i].word.substring(0, words[i].word.indexOf("#") + 1) + "]"

                let i1 = indexOf(chord, l1)
                let i2 = indexOf(chord, l2)

                if(i1 !== -1){
                    words[i].word = l1[(i1 + 1) % l1.length].replace("]", "") + words[i].word.substring(words[i].word.indexOf("#") + 1)

                }else{
                    words[i].word = l2[(i2 + 1) % l2.length].replace("]", "") + words[i].word.substring(words[i].word.indexOf("#") + 1)
                }

            }
            else{
            
                let i1 = indexOf(words[i].word.replace(" ", ""), l1)
                let i2 = indexOf(words[i].word.replace(" ", ""), l2)

                if (i1 !== -1) {
                  words[i].word = l1[((i1 + 1) % l1.length)]
                } else {
                  words[i].word = l2[((i2 + 1) % l2.length)]
                }
            }
        }
    }

    let firstChord = getFirstChord()
    //console.log("first chord = " + firstChord)
    //console.log("original chord = " + originalChord)
    if(firstChord != originalChord){
        chordColor = "yellow"
    }else{
        chordColor = "green"
    }

    drawCanvas()
}

function isComplexChord(chord){
    return (chord.indexOf("/") !== -1)
}

function isSharpChord(chord){
    return (chord.indexOf("#") !== -1)
}

function getNewChordDown(chord, dir){
    let i1 = indexOf(chord, l1)
    let i2 = indexOf(chord, l2)

    if(i1 !== -1){
        if(dir === "up"){
            return l1[((i1 + 1) % l1.length)]
        }else{ // dir === down
            if((i1 - 1) < 0){
                return l1[l1.length - 1]
            }else{
                return l1[i1 - 1]
            }
        }
    }else{
        if(dir === "up"){
            return l2[((i2 + 1) % l2.length)]
        }else{
            if((i2 - 1) < 0){
                return l2[l2.length - 1]
            }else{
                return l2[i2 - 1]
            }
        }
    }
}

function transposeDown() {
    for (var i = 0; i < words.length; i++) {
        if (words[i].chord) {

            if(isComplexChord(words[i].word)){
                let splits = words[i].word.split("/")
                
                splits[0] += "]"
                splits[1] = "[" + splits[1]

                //console.log(splits)

                let part1 = getNewChord(splits[0], "down")
                let part2 = getNewChord(splits[1], "down")

                part1 = part1.replace("[", "")
                part1 = part1.replace("]", "")

                part2 = part2.replace("[", "")
                part2 = part2.replace("]", "")

                //console.log("part 1 = " + part1)
                //console.log("part 2 = " + part2)
                

                words[i].word = "[" + part1 + "/" + part2 + "]"
            }else if (isSharpChord(words[i].word)){
                //console.log("isSharpChord")
                let chord = words[i].word.substring(0, words[i].word.indexOf("#") + 1) + "]"

                let i1 = indexOf(chord, l1)
                let i2 = indexOf(chord, l2)

                if(i1 !== -1){
                    if((i1 - 1) < 0){
                        //console.log("chord is " + words[i].letter)
                        //console.log("turing chord into " + l1[l1.length - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                        words[i].word = l1[l1.length - 1].replace("]", "") + words[i].word.substring(words[i].word.indexOf("#") + 1)
                        //console.log("XXX 1 " + l1[l1.length - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                    }else{
                        //console.log("chord is " + words[i].letter)
                        //console.log("turing chord into " + l1[i1 - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                        words[i].word = l1[i1 - 1].replace("]", "") + words[i].word.substring(words[i].word.indexOf("#") + 1)
                        //console.log("XXX 2" + l1[i1 - 1].replace("]", "") + words[i].letter.substring(words[i].letter.indexOf("#")))
                    }
                }else{

                    if((i2 - 1) < 0){
                        words[i].word = l2[l2.length - 1].replace("]", "") + words[i].word.substring(words[i].word.indexOf("#") + 1)
                    }else{
                        words[i].word = l2[i2 - 1].replace("]", "") + words[i].word.substring(words[i].word.indexOf("#") + 1)
                    }

                }

                //console.log(chord)

            }else{

                let i1 = indexOf(words[i].word.replace(" ", ""), l1)
                let i2 = indexOf(words[i].word.replace(" ", ""), l2)
                
                //console.log("1words[i] = " + words[i].letter)
                if (i1 !== -1) {
    
                    if ((i1 - 1) < 0) {
                        words[i].word = l1[l1.length - 1]
                    } else {
                        words[i].word = l1[i1 - 1]
                    }
    
                } else {
                    if ((i2 - 1) < 0) {
                        words[i].word = l2[l2.length - 1]
                    } else {
                        words[i].word = l2[i2 - 1]
                    }
                }

            }   
            //console.log("2words[i] = " + words[i].letter)
        }
    }

    let firstChord = getFirstChord().replace("[", "").replace("]", "")
    //console.log("first chord = " + firstChord)
    //console.log("original chord = " + originalChord)
    console.log(firstChord + " === " + originalChord)
    if(firstChord != originalChord){
        chordColor = "yellow"
    }else{
        console.log("Turning green")
        chordColor = "green"
    }

    drawCanvas()
}

function getFirstChord(){
    for(let word of words){
        if(word.chord){
            return word.word
        }
    }
}
 
function getWordAtLocation(aCanvasX, aCanvasY) {

  //locate the word near aCanvasX,aCanvasY co-ordinates
  //aCanvasX and aCanvasY are assumed to be X,Y loc
  //relative to upper left origin of canvas

  //used to get the word mouse is clicked on

  let context = canvas.getContext('2d')

  for (let i = 0; i < words.length; i++) {
    let wordWidth = context.measureText(words[i].word).width
    if ((aCanvasX > words[i].x && aCanvasX < (words[i].x + wordWidth)) &&
      (aCanvasY > words[i].y - wordHeight && aCanvasY < words[i].y)) {
      //set word targeting rectangle for debugging
      wordTargetRect = {
        x: words[i].x,
        y: words[i].y - wordHeight,
        width: wordWidth,
        height: wordHeight
      }
      return words[i]
    } //return the word found
  }
  return null //no word found at location
}

function drawCanvas() {

  let context = canvas.getContext('2d')
  let lyricFillColor = 'cornflowerblue'
  let lyricStrokeColor = 'blue'
  let chordFillColor = 'green'
  let transposedChordFillColor = 'orange'
  let chordStrokeColor = 'green'

  context.fillStyle = 'white'
  context.fillRect(0, 0, canvas.width, canvas.height) //erase canvas

  context.font = '' + fontPointSize + 'pt ' + editorFont
  context.fillStyle = 'cornflowerblue'
  context.strokeStyle = 'blue'

  //draw drag-able lyric and chord words
  for (let i = 0; i < words.length; i++) {
    let data = words[i]
    //console.log(data)
    // if (data.lyric) {
    //   context.fillStyle = lyricFillColor
    //   context.strokeStyle = lyricStrokeColor
    // }
    // if (data.chord) {
    //   if (transposedByNSemitones === 0) {
    //     context.fillStyle = chordFillColor
    //     context.strokeStyle = chordStrokeColor

    //   } else {
    //     context.fillStyle = transposedChordFillColor
    //     context.strokeStyle = transposedChordFillColor
    //   }

    // }

    if(data.chord){
      context.strokeStyle = chordColor
      context.fillText(data.word.substring(1, data.word.length - 1), data.x, data.y)
      context.strokeText(data.word.substring(1, data.word.length - 1), data.x, data.y)
    }else{
      context.strokeStyle = "blue"
      context.fillText(data.word, data.x, data.y)
      context.strokeText(data.word, data.x, data.y)
    }

  }

  //draw box around word last targeted with mouse -for debugging
  //context.strokeRect(wordTargetRect.x, wordTargetRect.y, wordTargetRect.width, wordTargetRect.height);

  /*
    context.fillStyle = 'red';
    movingString.stringWidth = context.measureText(	movingString.word).width;
    context.fillText(movingString.word, movingString.x, movingString.y);
	*/


}

function getCanvasMouseLocation(e) {
  //provide the mouse location relative to the upper left corner
  //of the canvas

  /*
  This code took some trial and error. If someone wants to write a
  nice tutorial on how mouse-locations work that would be great.
  */
  let rect = canvas.getBoundingClientRect()

  //account for amount the document scroll bars might be scrolled
  let scrollOffsetX = $(document).scrollLeft()
  let scrollOffsetY = $(document).scrollTop()

  let canX = e.pageX - rect.left - scrollOffsetX
  let canY = e.pageY - rect.top - scrollOffsetY

  return {
    canvasX: canX,
    canvasY: canY
  }

}

function handleMouseDown(e) {

  let canvasMouseLoc = getCanvasMouseLocation(e)
  let canvasX = canvasMouseLoc.canvasX
  let canvasY = canvasMouseLoc.canvasY
  //console.log("mouse down:" + canvasX + ", " + canvasY)

  wordBeingMoved = getWordAtLocation(canvasX, canvasY)
  //console.log(wordBeingMoved.word);
  if (wordBeingMoved != null) {
    deltaX = wordBeingMoved.x - canvasX
    deltaY = wordBeingMoved.y - canvasY
    $("#canvas1").mousemove(handleMouseMove)
    $("#canvas1").mouseup(handleMouseUp)

  }

  // Stop propagation of the event and stop any default
  //  browser action

  e.stopPropagation()
  e.preventDefault()

  drawCanvas()
}

function handleMouseMove(e) {

  //console.log("mouse move");

  let canvasMouseLoc = getCanvasMouseLocation(e)
  let canvasX = canvasMouseLoc.canvasX
  let canvasY = canvasMouseLoc.canvasY

  //console.log("move: " + canvasX + "," + canvasY)

  wordBeingMoved.x = canvasX + deltaX
  wordBeingMoved.y = canvasY + deltaY

  e.stopPropagation()

  
  drawCanvas()
}

function handleMouseUp(e) {
  //console.log("mouse up")
  e.stopPropagation()

  //remove mouse move and mouse up handlers but leave mouse down handler
  $("#canvas1").off("mousemove", handleMouseMove) //remove mouse move handler
  $("#canvas1").off("mouseup", handleMouseUp) //remove mouse up handler

  if(wordBeingMoved !== null){
    console.log("Not null " + wordBeingMoved.word)
    removeFromMatrix(wordBeingMoved.word)
    //let v = getMatrixVector(wordBeingMoved.y)
    insertSortedToVector(wordBeingMoved)
    console.log(wordMatrix)
  }

  drawCanvas() //redraw the canvas
}


function handleTimer() {
  movingString.x = (movingString.x + 5 * movingString.xDirection)
  movingString.y = (movingString.y + 5 * movingString.yDirection)

  //keep moving string within canvas bounds
  if (movingString.x + movingString.stringWidth > canvas.width) movingString.xDirection = -1
  if (movingString.x < 0) movingString.xDirection = 1
  if (movingString.y > canvas.height) movingString.yDirection = -1
  if (movingString.y - movingString.stringHeight < 0) movingString.yDirection = 1

  drawCanvas()
}

//KEY CODES
//should clean up these hard coded key codes
const ENTER = 13
const RIGHT_ARROW = 39
const LEFT_ARROW = 37
const UP_ARROW = 38
const DOWN_ARROW = 40


function handleKeyDown(e) {

  //console.log("keydown code = " + e.which );
  let keyCode = e.which
  if (keyCode == UP_ARROW | keyCode == DOWN_ARROW) {
    //prevent browser from using these with text input drop downs
    e.stopPropagation()
    e.preventDefault()
  }

}

function handleKeyUp(e) {
  //console.log("key UP: " + e.which);
  if (e.which == RIGHT_ARROW | e.which == LEFT_ARROW | e.which == UP_ARROW | e.which == DOWN_ARROW) {
    //do nothing for now
  }

  if (e.which == ENTER) {
    handleSubmitButton() //treat ENTER key like you would a submit
    $('#userTextField').val('') //clear the user text field
  }

  e.stopPropagation()
  e.preventDefault()

}

function addToMatrix(vector, obj){
  if(vector.length === 0){
    wordMatrix.push({y: obj.y, a: vector, sortedInsert: insertSortedToVector})
    vector.push(obj)
  }else{
    getMatrixVector(obj.y).a.push(obj)
  }
}

function removeFromMatrix(word){
  for(let vector of wordMatrix){
    for(let i = 0; i < vector.a.length; i++){
      if(vector.a[i].word === word){
        return vector.a.splice(i, 1)[0]
      }
    }
  }
}

function parseChordProFormat(chordProLinesArray) {
  //parse the song lines with embedded chord pro chords into individual movable words

  transposedByNSemitones = 0 //reset transposition in semitones

  //clear any newline or return characters as a precaution --might not be needed
  for (let i = 0; i < chordProLinesArray.length; i++) {
    chordProLinesArray[i] = chordProLinesArray[i].replace(/(\r\n|\n|\r)/gm, "");
  }


  //add the lines of text to html <p> elements
  let textDiv = document.getElementById("text-area")
  textDiv.innerHTML = ''

  for (let i = 0; i < chordProLinesArray.length; i++) {
    let line = chordProLinesArray[i]
    console.log(chordProLinesArray[i])
    textDiv.innerHTML = textDiv.innerHTML + `<p> ${line}</p>`

    let lyricLine = '' //string representing the lyrics and chords

    //separate chords and lyrics by a blank. Preserve the [] characters in chord symbols
    for (let charIndex = 0; charIndex < line.length; charIndex++) {
      let ch = line.charAt(charIndex)
      // if (ch == ']') {
      //   lyricLine = lyricLine + ch + ' '
      // } else if (ch == '[') {
      //   lyricLine = lyricLine + ' ' + ch
      // } else 
      lyricLine = lyricLine + ch

    }


    //console.log("lyricLine = " + lyricLine)

    //Now turn lyrics line into individual drag-able words
    //Create Movable Words
    const characterWidth = canvas.getContext('2d').measureText('m').width; //width of one character

    //Make drag-able words
    lyricLine += ' '; //add blank to lyrics line just so it conveniently ends in a blank
    if (lyricLine.trim().length > 0) {
      let theLyricWord = ''
      let theLyricLocationIndex = -1
      let vectorInMatrix = []
      for (let j = 0; j < lyricLine.length; j++) {
        let ch = lyricLine.charAt(j)
        if(ch === '[' && lyricLine.charAt(j - 1) !== ' '){ // inside an embedded chord
          //console.log("inside")
          // oh no we're at a chord that's within a word. We know this because 
          // if a = ['b', 'r', 'o', '[', 'G', '#', 'm', 'i', 'n', ']', 'w, 'n'] and i = 3
          // then the theory that if chord = a[i] -> a[i + 7]
          // and word = a[0] -> a[i-1] + a[i + 7] -> a[a.length]
          // holds true
          let charWord = ""
          let chordTheLyricLocationIndex = theLyricLocationIndex
          while(ch !== ']'){ // oh so start accumulating the letters that go into the chord
            j++
            ch = lyricLine.charAt(j)
            charWord += ch
            chordTheLyricLocationIndex = j
          }
          
          let charObj = {
              word: charWord.replace("[", "").replace("]", ""), // clean up the [ & ] because you said to 
              x: leftMargin + chordTheLyricLocationIndex * characterWidth,
              y: (topMargin + i * 2 * lineHeight + lyricLineOffset) - 30,
              sortedInsert: insertSortedToVector,
              chord: "chord"
          }
  
          // now add it 
          
          words.push(charObj)
          
          addToMatrix(vectorInMatrix, charObj)
          


          // now since we're inside a word lets finish this word, using whats already been accumulated
          while(ch !== " " ){
            j ++
            ch = lyricLine.charAt(j)            

            theLyricWord += ch
            
            if(chordTheLyricLocationIndex === -1){
              chordTheLyricLocationIndex = j
            }
            if(lyricLine.charAt(j+1) === "[") break;
          }
          console.log("TheLyricWord = " + theLyricWord)

          let wordObj = {
            word: theLyricWord.replace("[", "").replace("]", ""),
            x: leftMargin + chordTheLyricLocationIndex * characterWidth,
            y: topMargin + i * 2 * lineHeight + lyricLineOffset,
            sortedInsert: insertSortedToVector,
            lyric: "lyric"
          }

          words.push(wordObj)

          addToMatrix(vectorInMatrix, wordObj)

          theLyricWord = ""
          
          theLyricLocationIndex = -1     
          
          
        }else if(ch === "["){
          //console.log("Inside else if")
          let theChordWord = ""
          let chordTheLyricLocationIndex = theLyricLocationIndex

          while(ch !== "]"){
            theChordWord += ch
            j ++
            ch = lyricLine.charAt(j)
            
            chordTheLyricLocationIndex = j
          }

          let chordObj = {
            word: theChordWord.replace("[", "").replace("]", ""),
            x: leftMargin + chordTheLyricLocationIndex * characterWidth,
            y: (topMargin + i * 2 * lineHeight + lyricLineOffset) - 30,
            sortedInsert: insertSortedToVector,
            chord: "chord"
          }

          words.push(chordObj)   
          theLyricLocationIndex = -1     

          addToMatrix(vectorInMatrix, chordObj)
         }
        else if (ch == ' ') {
          //start or end of word or chord symbol
          if (theLyricWord.trim().length > 0) {
            //console.log("theLyricLocationIndex = " + theLyricLocationIndex)
            //console.log(theLyricLocationIndex)
            let word = {
              word: theLyricWord.replace("[", "").replace("]", ""),
              x: leftMargin + theLyricLocationIndex * characterWidth,
              y: topMargin + i * 2 * lineHeight + lyricLineOffset,
              sortedInsert: insertSortedToVector
            }
            //designate word as either a lyric or a chord symbol
            if (word.word.endsWith(']')){
              word.chord = 'chord'
              word.y -= 30
            } 
            else word.lyric = 'lyric'

            addToMatrix(vectorInMatrix, word)
            words.push(word)

          }
          theLyricWord = ''
          theLyricLocationIndex = -1

        } else {
          //its part of a lyric word
          theLyricWord += ch
          if (theLyricLocationIndex === -1){
            theLyricLocationIndex = j
            //console.log("lyricLocal = " + theLyricLocationIndex)
          } 
        }
      }
    } //end make lyric chord words

  }
  originalChord = getFirstChord();
  console.log(wordMatrix)
  //constructMatrixFromWords()
  constructParaFromMatrix()
}

/**
 * Like substring but for arrays
 * @param {and array of data} arr 
 * @param {start index inclusive} start 
 * @param {finish index exclusive} finish 
 */
function subIndex(arr, start, finish){
  let newArr = []
  for(var i = start; i < finish; i ++){
    newArr.push(arr[i])
  }
  return newArr
}

/**
 * Inserts the given word object into a vector. The word is placed inbetween the last word whose x value is less than the parameter word's
 * x value and the first word whose x value is great that the parameter word's x value.
 * @param {A word object} word 
 */
function insertSortedToVector(word){
  let v = getMatrixVector(word.y)
  let index = -1
  for(let i = 0; i < v.a.length - 1; i++){
    if(v.a[i].x <= word.x && v.a[i + 1].x > word.x){
      index = i
    }
  }

  if(index !== -1){
    
    let splice1 = subIndex(v.a, 0, index + 1) //v.a.splice(0, index + 1)
    let splice2 = subIndex(v.a, index + 1, v.a.length) //v.a.splice(index + 2, v.length - 1)
    
    splice1 = splice1.concat(word, splice2)
    v.a = splice1
  }

}

/**
 * Returns the vector with the minimum absolute difference between from the parameter y value.
 * @param {A integer representing a y coordinate} y 
 */
function getMatrixVector(y){
  let closestVector = undefined
  for(let vector of wordMatrix){
    if(closestVector === undefined){
      closestVector = vector
    }else if(Math.abs(vector.y - y) < Math.abs(closestVector.y - y)){
      closestVector = vector
    }
  }
  return closestVector
}

function transpose(theWords, semitones) {
  //Transpose any of the chords in the array of word objects theWords by
  //semitones number of musical steps or semi-tones.
  //semitones is expected to be an integer between -12 and +12

  if (semitones === 0) return //nothing to do

  transposedByNSemitones += semitones
  if (transposedByNSemitones >= 12) transposedByNSemitones -= 12
  if (transposedByNSemitones <= -12) transposedByNSemitones += 12

  for (let i = 0; i < words.length; i++) {
    if (words[i].chord) {
      words[i].word = transposeChord(words[i].word, semitones)
    }
  }
}

function transposeChord(aChordString, semitones) {
  //console.log(`transposeChord: ${aChordString} by ${semitones}`)
  /*transpose aChordString by semitones
  aChordString is expected to be like: '[Gm7]' or '[F#maj7]'
  Strategy: look for the position of the chord letter name in hard-coded array of
  letter names and if found replace the characters with the ones offset by the argument
  semitones.
  For example to transpose A#m up by three semitones find for A# in RootNamesWithSharps
  array (which would be 1) then replace A# with the name found at RootsNamesWithSharps[1+3]
  which would be C#. Hence A#m transposed up three semitones would be C#m.
  */
  const RootNamesWithSharps = ['A', 'A#', 'B', 'C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#']
  const RootNamesWithFlats = ['A', 'Bb', 'B', 'C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab']
  let rootNames = RootNamesWithSharps
  let rootNameIndex = -1
  let transposedChordString = ''
  for (let i = 0; i < aChordString.length; i++) {
    if (rootNames.findIndex(function(element) {
        return element === aChordString[i]
      }) === -1) {
      //character is not start of a chord root name (i.e. is not A,B,C,D,E,F, or G)
      if ((aChordString[i] !== '#') && (aChordString[i] !== 'b')) //skip # and b suffix
        transposedChordString += aChordString[i]
    } else {
      //character is start of a chord name root (i.e. A,B,C,D,E,F, or G)
      let indexOfSharp = -1
      let indexOfFlat = -1
      //check to see if we are dealing with names like A# or Bb
      if (i < aChordString.length - 1) {
        indexOfSharp = RootNamesWithSharps.findIndex(function(element) {
          return element === (aChordString[i] + aChordString[i + 1])
        })
        if (indexOfSharp !== -1) transposedChordString += RootNamesWithSharps[(indexOfSharp + 12 + semitones) % 12]
        indexOfFlat = RootNamesWithFlats.findIndex(function(element) {
          return element === (aChordString[i] + aChordString[i + 1])
        })
        if (indexOfFlat !== -1) transposedChordString += RootNamesWithFlats[(indexOfFlat + 12 + semitones) % 12]
      }
      if ((indexOfSharp === -1) && (indexOfFlat === -1)) {
        //chord name is letter without a # or b
        let index = rootNames.findIndex(function(element) {
          return element === aChordString[i]
        })
        if (index !== -1) transposedChordString += rootNames[(index + 12 + semitones) % 12]
      }
    }
  }
  return transposedChordString
}

function handleTransposeUpButton() {
  //transpose(words, 1)
  //drawCanvas()

  transposeUp()
}

function handleTransposeDownButton() {
  //transpose(words, -1)
  //drawCanvas()
  transposeDown()
}

function splitChordFromString(str){
  if(str.indexOf("[") !== -1){
    let word = str.substring(0, str.indexOf("[")) + str.substring(str.indexOf("]") + 1, str.length)
    let chord = w.substring(w.indexOf("["), w.indexOf("]") + 1)
    return {w: word, c: chord}
  }
}

function handleSubmitButton() {

  let userText = $('#userTextField').val() //get text from user text input field
  //clear lines of text in textDiv
  let textDiv = document.getElementById("text-area")
  textDiv.innerHTML = ''

  if (userText && userText !== '') {
    let userRequestObj = {
      text: userText
    }
    let userRequestJSON = JSON.stringify(userRequestObj)
    //$('#userTextField').val('') //clear the user text field

    //alert ("You typed: " + userText);
    $.post("fetchSong", userRequestJSON, function(data, status) {
      //console.log("data: " + data)
      //console.log("typeof: " + typeof data)
      let responseObj = data
      movingString.word = responseObj.text
      words = [] //clear drag-able words array;
      //console.log(responseObj)
      //console.log("responseObj.songLines = " + responseObj.songLines)
      if (responseObj.songLines) parseChordProFormat(responseObj.songLines);
    })
  }

}

function vectorToText(v){
  //console.log(v)
  let masterString = ""
  for(let w of v){
    if(w.chord){
      masterString += "[" + w.word + "]"
    }else{
      masterString += w.word + " "
    }
  }
  return masterString
}

function constructParaFromMatrix(){
  let domEle = document.getElementById("text-area")
  while(domEle.firstChild){
    domEle.firstChild.remove()
  }

  for(let vector of wordMatrix){
    let p = document.createElement("p")
    p.innerText = vectorToText(vector.a)
    domEle.appendChild(p)
  }
}

function convertParaToText(){
  let paraList = document.getElementsByTagName("p")
  let text = ""
  for(let p of paraList){
    text += p.innerHTML + "\n"
  }
  return text
}

function handleSaveAs(){
  let dataToSave = {
    fileN: $("#userTextField").val(),
    fileD: convertParaToText()
  }

  dataToSave = JSON.stringify(dataToSave)
  $.post("saveAs", dataToSave, function(data, status){
    //let obj = JSON.parse(data)

    if(data.status === 0) alert("successfully saved " + $("#userTextField").val())
    else alert("Unable to save " + $("#userTextField").val() + " to server directory.")
  })
}

$(document).ready(function() {
  //This is called after the broswer has loaded the web page

  //add mouse down listener to our canvas object
  $("#canvas1").mousedown(handleMouseDown)
  $("#userTextField").val("Brown Eyed Girl")
  $("#subB").click()

  $("#refreshB").click(constructParaFromMatrix)
  $("#saveAsB").click(handleSaveAs)
  $("#tUpB").click(transposeUp)
  $("#tDownB").click(transposeDown)

  //add key handler for the document as a whole, not separate elements.
  $(document).keydown(handleKeyDown)
  $(document).keyup(handleKeyUp)

  timer = setInterval(handleTimer, 100) //animation timer
  //clearTimeout(timer); //to stop timer

  drawCanvas()
})